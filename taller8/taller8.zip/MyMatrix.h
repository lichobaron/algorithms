#include <vector>
#include <algorithm>
#include <limits>

typedef double TData;
typedef std::vector< TData > TRow;
typedef std::vector< TRow > TMatrix;
static const TData inf = std::numeric_limits< TData >::max( );