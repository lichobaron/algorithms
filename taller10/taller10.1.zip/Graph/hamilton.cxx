#include <iostream>
#include "Graph.h"
#include <algorithm>
#include <limits>

using namespace std;

//Hamilton por permutaciones
//// -------------------------------------------------------------------------
////HamiltonMasCorto: Encuentra la permutación que sea camino de Hamilton y sea el más corto
////Entradas:
////	- grafo : Grafo sobre el cual se hallarán los caminos de Hamilton.
////  - tam : Número de vertices que tiene el grafo.
////  - vertices :  Arreglo que contiene los vertices sobre los cuales se permutará.
////Salidas:
////	- T* : Arreglo que contiene la lista de nodos que forman el camino de Hamilton más corto.
//// -------------------------------------------------------------------------
template <class T>
T*  HamiltonMasCorto(Graph<T> *grafo,int tam,T vertices[])
{
  Vertex<char> *v;
  Vertex<char> *z;
  std::map<Vertex<char> *, int> aux;
  typename std::map<Vertex<char> *, int>::iterator it;
  bool isHamilton = false;
  int min = std::numeric_limits<int>::max();
  int cant = 0, total = 0, w = 0;
  T *minimo = new T[tam];
  do
  {
    w = 0;
    for (int i = 0; i < tam; i++)
    {
      v = grafo->searchVertex(vertices[i]);
      aux = v->getAdy();
      if (i + 1 == tam)
      {
        z = grafo->searchVertex(vertices[0]);
        it = aux.find(z);
        if (it != aux.end())
        {
          isHamilton = true;
          w += it->second;
        }
        else
        {
          isHamilton = false;
          break;
        }
      }
      else
      {
        z = grafo->searchVertex(vertices[i + 1]);
        it = aux.find(z);
        if (it != aux.end())
        {
          isHamilton = true;
          w += it->second;
        }
        else
        {
          isHamilton = false;
          break;
        }
      }
    }
    if (isHamilton)
    {
      cant += 1;
      if (min > w)
      {
        for (int j = 0; j < tam; j++)
        {
          minimo[j] = vertices[j];
        }
      }
    }
    total += 1;
  } while (std::next_permutation(vertices, vertices + tam));
  return minimo;
}

//Hamilton por aproximación
//// -------------------------------------------------------------------------
////Se encuentra en Graph.hxx en las funciones:
//// - dijkstraMST: Encuentra el minimun spaning tree de un grafo por medio del alg de dijkstra.
//// - depthFirstSearch: Realiza el recorrido preorden de un grafo
//// -------------------------------------------------------------------------


int main(){

    //Creación e inicialización del grafo.
    Graph<char> *grafo = new Graph<char>(false);
    char vertices[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'};
    int tam = sizeof vertices / sizeof *vertices;
    for (int i=0; i <tam;i++)
    {
        grafo->addVertex(vertices[i]);
    }

    grafo->addEdge('A', 'B', 1);
    grafo->addEdge('A', 'C', 2);
    grafo->addEdge('A', 'D', 1);
    grafo->addEdge('A', 'E', 2);
    grafo->addEdge('A', 'F', 3);
    grafo->addEdge('A', 'G', 3);
    grafo->addEdge('A', 'H', 2);

    grafo->addEdge('B', 'C', 1);
    grafo->addEdge('B', 'D', 4);
    grafo->addEdge('B', 'E', 5);
    grafo->addEdge('B', 'F', 6);
    grafo->addEdge('B', 'G', 7);
    grafo->addEdge('B', 'H', 1);

    grafo->addEdge('C', 'D', 4);
    grafo->addEdge('C', 'E', 5);
    grafo->addEdge('C', 'F', 6);
    grafo->addEdge('C', 'G', 7);
    grafo->addEdge('C', 'H', 1);

    grafo->addEdge('D', 'E', 1);
    grafo->addEdge('D', 'F', 6);
    grafo->addEdge('D', 'G', 7);
    grafo->addEdge('D', 'H', 1);

    grafo->addEdge('E', 'F', 1);
    grafo->addEdge('E', 'G', 1);
    grafo->addEdge('E', 'H', 7);

    grafo->addEdge('F', 'G', 1);
    grafo->addEdge('F', 'H', 7);

    grafo->addEdge('G', 'H', 7);

    //Solución por permutaciones
    cout <<"Camino por permutaciones: "<<endl;
    cout << HamiltonMasCorto(grafo,tam,vertices) << endl;
    
    //Solución por aproximación
    cout <<"Camino por aproximación: "<<endl;
    Graph<char> *g = grafo->dijkstraMST('A');
    g->depthFirstSearch('A');
    cout<<endl;
    return 0;
}