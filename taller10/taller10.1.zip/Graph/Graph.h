#ifndef __Graph__HH__
#define __Graph__HH__

#include <set>
#include <map>
#include <queue>
#include <stack>
#include "Vertex.h"

template < class T >
struct VertComparator
{
    bool operator()(const Vertex<T>* a, const Vertex<T>* b ) const
    {
        return a->getData() < b->getData();
    }
};

template <class T>
class Graph
{
protected:
   std::set<Vertex<T> *, VertComparator<T>> vertexs;
   bool type;

public:
  Graph(bool type);
  void addVertex(T data);
  void addEdge(T data1, T data2, int weight);
  void eraseEdge(T data1, T data2);
  void eraseVertex(T data);
  Vertex<T>* searchVertex(T data);
  void resetVisited();
  void resetValue();
  void flatTrack();
  //FUNCION DE PREORDEN
  void depthFirstSearch(T begin);
  void breadthFirstSearch(T begin);
  void dijkstra(T begin, T end);
  //FUNCION DEL MST
  Graph<T> * dijkstraMST(T begin);
};

#include "Graph.hxx"
#endif
